CREATE VIEW article_user_trade_view AS
  SELECT
    `last`.`trades`.`tradeTime`    AS `tradeTime`,
    `last`.`trades`.`tradeFlowers` AS `tradeFlowers`,
    `u`.`username`                 AS `username`,
    `last`.`trades`.`authorID`     AS `authorID`,
    `a`.`articleID`                AS `articleID`,
    `u`.`userID`                   AS `userID`,
    `a`.`title`                    AS `title`
  FROM ((`last`.`trades`
    JOIN `last`.`users` `u` ON ((`u`.`userID` = `last`.`trades`.`userID`))) JOIN `last`.`articles` `a`
      ON ((`a`.`articleID` = `last`.`trades`.`articleID`)));
