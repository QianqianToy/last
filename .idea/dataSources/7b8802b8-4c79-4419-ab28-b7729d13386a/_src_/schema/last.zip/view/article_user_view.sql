CREATE VIEW article_user_view AS
  SELECT
    `a`.`title`          AS `title`,
    `a`.`content`        AS `content`,
    `a`.`writeTime`      AS `writeTime`,
    `a`.`upNum`          AS `upNum`,
    `a`.`downNum`        AS `downNum`,
    `a`.`flowers`        AS `flowers`,
    `u`.`fansNum`        AS `fansNum`,
    `u`.`userID`         AS `userID`,
    `a`.`articleID`      AS `articleID`,
    `a`.`username`       AS `username`,
    `u`.`photo`          AS `photo`,
    `u`.`birthday`       AS `birthday`,
    `u`.`sign`           AS `sign`,
    `u`.`signature`      AS `signature`,
    `a`.`articleBigType` AS `articleBigType`
  FROM `last`.`articles` `a`
    JOIN `last`.`users` `u`
  WHERE (`a`.`username` = `u`.`username`);
